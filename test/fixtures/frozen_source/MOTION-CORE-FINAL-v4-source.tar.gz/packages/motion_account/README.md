# Motion account foundation

One Supabase identity serves Ostinato, Gravita, Choreia, JabLab, and Lissom.
Subscription rights remain scoped to the signed-in user **and** one app.
Version 0.2.0 adds the recovery listenable below and requires the deletion
response upgrade described here. Entitlement fixes ship as version 0.1.1.

Host apps initialize `MotionAccountRuntime` once before `runApp` with the same
Motion project URL and publishable key, their own `MotionApp` value, and the
matching callback `com.yulalab.<app>://auth/callback`. The native iOS and
Android callback registrations and the Supabase Auth redirect allow-list must
match that exact URI. The runtime exposes `account` for `MotionAccountPage` and
`userId` as a `ValueListenable<String?>` for local-data ownership. Hosts must
wrap their shell in `MotionIdentityGate`: null ID may mean signed out, still
verifying, or network unavailable. Only `signedOut` may open guest history;
only `verified` may open account history. A stored session does not prove that
the account still exists until the Auth server confirms it.
If verification is unavailable, the gate offers a local-only guest path. It
discards the unverified cached session without deleting account-owned files;
the user must sign in again to reopen that account's history.
Pass `runtime.isPasswordRecovery` to the page's `initialPasswordRecovery`
parameter when routing rebuilds after an auth callback.
For callbacks that retain the same user and route, listen to
`runtime.passwordRecovery` (`ValueListenable<bool>`) and rebuild the account
page with that value. The existing bool getter remains available as a snapshot.
The page also responds when `initialPasswordRecovery` changes on an existing
widget. Password-update success, sign-out, and account changes clear recovery.
Identity verification has a ten-second deadline. A stalled request closes the
gate with Retry and Continue as guest; a late response cannot reopen it.

Both account widgets handle raw SDK auth-stream errors separately from the
runtime. The account page keeps entered credentials and the recovery form,
shows a safe retry message, and suppresses a pending profile result. The
membership page retires its current sale lifetime: retained purchase actions,
pending offers and cached auth events cannot reopen it after an auth error.
Retry verified identity in the host before opening a new membership page.
These handlers never delete local history or enable the closed paid gate.

`MotionAccountPage.clearLocalData` receives the captured user ID and erases this
app's local records after confirmed remote common-account deletion. The host owns its
local data and must clear only that user's records. On a restored session,
`onDeletedAccount` erases records if Auth explicitly returns `user_not_found`.
The `localAccountIds` callback lists this app's existing user-owned files. At
startup and after sign-out, a separate anonymous client checks the server's
deletion receipt for each ID. Only a confirmed receipt allows local cleanup;
ordinary sign-out and network failure keep files. The server retains only a
digest of each deleted random account ID. Store subscriptions are managed
through the Apple or Google account; this package does not cancel them.

Deletion captures the initiating UUID, Session reference and token before dispatch. The
client requires HTTP 200 with `deleted: true` and the same `userId` before local
cleanup, and it never signs out a replacement session after cleanup. Deploy the
matching `motion-delete-account` response before pinning this Core revision in
consumer release builds. The new endpoint accepts older clients that omit
`expectedUserId`; the verified token remains its authority. A legacy or malformed
response makes the new client preserve files until independent receipt cleanup
confirms deletion. This source change does not prove provider deployment.
Membership checks and purchase verification pin their initiating session token
and Session reference too. A changed account or any replacement Session discards
the response, even when its UUID and token values are unchanged. Identity replies
and cleanup-side sign-out also require the original Session reference; a silent
same-user `recoverSession` cannot inherit an older request's authority. Confirmed
UUID cleanup still runs for that UUID independently of this sign-out guard.
The default membership page belongs to its opening Session: replacing it retires
retained sale actions and held store acknowledgements. Reopen the page after
verified identity retry, including when credential refresh replaces the Session.
Auth-stream replay of an unchanged opening Session keeps the page usable.

The account deletion dialog captures its account client, Session, UUID and local
cleanup callback when opened. Confirmation dispatches only while that page and
the captured Supabase client/Session remain current; a host may rebuild a wrapper
around that same client without losing an unchanged-session confirmation.
A retained dialog reads translations
from its own context, so a disposed account page or a locale change cannot make
it use a defunct State. Hosts still capture their storage epoch and resource
handles before opening the page; the Core Session guard does not replace that
local ownership ticket or change the host's ordinary token-refresh epoch policy.
The generic purchase coordinator remains UUID-scoped; other hosts must bind its
existing `currentUserId` callback to their own admitted identity lifetime.
Verified expired/revoked restores replace the matching cached right;
unavailable or unverified checks preserve cache and leave store work retryable.

The package rejects non-HTTPS remote service URLs in development and release.
Loopback HTTP is accepted only outside release builds for the local test stack.
Never embed a service-role key in a mobile app. The publishable key is public
configuration and access depends on RLS and server-side verification.

The current five-app work may use a local path dependency for development.
Before a release candidate, every app must pin the same reviewed Core commit
by immutable Git SHA; a developer-machine path is not a releasable dependency.

Local checks: `flutter analyze --no-pub` and `flutter test --no-pub
test/account_page_test.dart test/runtime_configuration_test.dart
test/runtime_identity_test.dart test/account_lifecycle_race_test.dart`. The
`local_account_integration_test.dart` also requires the dedicated local Motion
Supabase and Mailpit environment variables documented in that test file.
